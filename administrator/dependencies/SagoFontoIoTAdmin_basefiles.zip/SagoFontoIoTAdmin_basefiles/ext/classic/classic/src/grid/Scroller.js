//<debug>
Ext.define('Ext.grid.Scroller', {
    constructor: Ext.deprecated()
});
//</debug>
